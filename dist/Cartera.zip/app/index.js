$(document).ready(function() {
  
  /* axios({ 
      method: 'GET', 
      url: 'https://cors-anywhere.herokuapp.com/http://172.16.15.119:9191/api/statement?pagesize=10', 
      headers: {"Authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xNzIuMTYuMTUuMTE5OjkxOTFcL2FwaVwvYXV0aFwvbG9naW4iLCJpYXQiOjE1NDAwMDcyOTYsImV4cCI6MTU0MDAxMDg5NiwibmJmIjoxNTQwMDA3Mjk2LCJqdGkiOiJqT3RjQUpVYmdJNkZXSUh1Iiwic3ViIjoiMTExNTczNTgyMCIsInBydiI6IjEzZThkMDI4YjM5MWYzYjdiNjNmMjE5MzNkYmFkNDU4ZmYyMTA3MmUiLCJuYW1lIjoiSkVJQ0tTT04gRkFCSUFOIENSVVogUk9EUklHVUVaICIsImljZWJlcmdJZCI6IjEwMDA0ODQ1OCJ9.GACRr6nzyQuHg8Mws5CvjAlwKtdoiJrHZPps2vOgttk"},
      responseType: 'text',
    }).then((response) =>{
      console.log(response);
    }).catch((error) => {
      console.log(error);
    })
  */

 var settings = {
  "async": true,
  "crossDomain": true,
  "url": "https://cors-anywhere.herokuapp.com/http://172.16.15.119:9191/api/statement?pagesize=10",
  "method": "GET",
  "headers": {
    "authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xNzIuMTYuMTUuMTE5OjkxOTFcL2FwaVwvYXV0aFwvbG9naW4iLCJpYXQiOjE1NDAwNjYwODcsImV4cCI6MTU0MDA2OTY4NywibmJmIjoxNTQwMDY2MDg3LCJqdGkiOiJaQU1aMkFMbjR3VG1hakNSIiwic3ViIjoiMTExNTczNTgyMCIsInBydiI6IjEzZThkMDI4YjM5MWYzYjdiNjNmMjE5MzNkYmFkNDU4ZmYyMTA3MmUiLCJuYW1lIjoiSkVJQ0tTT04gRkFCSUFOIENSVVogUk9EUklHVUVaICIsImljZWJlcmdJZCI6IjEwMDA0ODQ1OCJ9.gG0-jxy2BtlGCyNMD6G9J9z2HS9xIlrfy5dsezGr-NU",
    "cache-control": "no-cache",
    "postman-token": "3e95d08b-0840-54ca-fed1-bb444b5d9f09"
  }
}

$.ajax(settings).done(function (response) {
  console.log(response);
});

  let arrayofData = null;
  fetch('https://cors-anywhere.herokuapp.com/https://jsonplaceholder.typicode.com/todos')
  .then(response => response.json())
  .then(json => {    
    arrayofData = json;
  })

  let example = $('#example').DataTable( {
    "ajax": {
      "url": "https://jsonplaceholder.typicode.com/todos",
      "dataSrc": ""
    },
    "columns": [
      {
          data: function (row, type, set) {
              return '';
          }
      },
      { data: "userId", title:  "userId"},
      { data: "id", title: "Id" },
      { data: "title", title: "title"  },
      { data: "completed", title: "completed" }, 
    ],
    columnDefs: [ {
        orderable: false,
        className: 'select-checkbox',
        targets:   0
    } ],
    select: {
        style: 'multi',
        selector: 'td:first-child'
    },
    searching: false,
    dom: 'Bfrtip',
    buttons: [
        'selectAll',
        'selectNone'
    ],
    language: {
      buttons: {
          selectAll: "Select all items",
          selectNone: "Select none"
      }
    },
    order: [[ 0, 'desc' ]]
  } ); 
  
  const arrayOfCheckedElements = [];
  
  example.on( 'deselect', function ( e, dt, type, indexes ) {
    console.log('deselect');    
    console.log(arrayofData[indexes]);
    const indexFromArray = arrayOfCheckedElements.indexOf(arrayofData[indexes]);
    if (indexFromArray !== -1) {
      arrayOfCheckedElements.splice(indexFromArray, 1);
      if(arrayOfCheckedElements.length === 0) {
        $("#button-wrapper").addClass("d-none");
      }
    }
    
  });
  example.on( 'select', function ( e, dt, type, indexes ) {
    console.log('select');    
    console.log(arrayofData[indexes]);
    arrayOfCheckedElements.push(arrayofData[indexes])
    $("#button-wrapper").removeClass("d-none");
  });
  
} );


